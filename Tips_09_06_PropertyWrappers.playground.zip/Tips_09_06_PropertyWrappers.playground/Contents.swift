//
//  A Demo for iOS Development Tips Weekly
//  by Steven Lipton (C)2018, All rights reserved
//  For videos go to http://bit.ly/TipsLinkedInLearning
//  For code go to http://bit.ly/AppPieGithub
//

//:#Property Wrappers
//: A demo to demonstrate Swift Property wrappers
import UIKit

@propertyWrapper struct RealPizzaCheese{
    private var name: String = ""
    var wrappedValue:String{
        set{ name = newValue}
        get{
            let cheese = name.lowercased() == "cheese" ? "Mozzarella" : name
            return cheese
        }
    }
    var projectedValue:String{
        return name
    }
    init (wrappedValue:String){
        name = wrappedValue
    }
}


struct PizzaItem{
    @RealPizzaCheese var topping1:String = "Cheese"
    @RealPizzaCheese var topping2:String = "Gorgonzola"
    var size:Int = 10
}


var a = PizzaItem()
a.topping1
a.topping2
a.topping2 = "cheese"
a.$topping2













